#!/bin/bash
wp="/usr/local/oneindex"
. $wp/functions.sh

bash <(iptables -S | grep "$wp" | sed "s|^..|iptables -D|g")
kill_path $wp/php 

if [ "$1" = "start" ];then
    for dport in $(cat $wp/oneindex.ini);do
        iptables -I INPUT -p tcp --dport $dport -m comment --comment "$wp" -j ACCEPT
        iptables -I INPUT -p udp --dport $dport -m comment --comment "$wp" -j ACCEPT
    done
    cd $wp/oneindex
    nohup $wp/php -S 0.0.0.0:$(cat $wp/oneindex.ini) >/dev/null 2>&1 &
fi
