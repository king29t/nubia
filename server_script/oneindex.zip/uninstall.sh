#!/bin/bash
wp="/usr/local/oneindex"
. $wp/functions.sh

stop_service

rm -rf $wp
rm -f /bin/oi

crontab -l | sed '/oneindex/d' | crontab -
