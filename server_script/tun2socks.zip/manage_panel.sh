#!/bin/bash
wp="/usr/local/tun2socks"
. $wp/functions.sh

panel(){
	color_status tv_status $wp/tun2sockS $wp/v2raY
    var=1
	
    echo
    echo -e "  $((var++)). 开/关${tv_status} tun2socks-v2ray${BLANK}"
    echo "  $((var++)). 卸载 tun2socks-v2ray"
    echo "  $((var++)). 编辑 v2ray 配置文件"
    echo
    colorRead ${YELLOW} "请选择" panel_choice

    var=1
    case $panel_choice in
        $((var++)) )
            if [ "$tv_status" = "$GREEN" ];then
                stop_service
            else
                start_service
            fi
            clear && panel
            ;;
        $((var++)) )
			if warning_read;then
				bash $wp/uninstall.sh
				clear && echo " tun2socks-v2ray 已卸载！"
			else
				clear && panel
			fi
            ;;
        $((var++)) )
            vi +79 $wp/config.json
			start_service
            clear && panel
            ;;
        *)
            clear && exit 0
            ;;
    esac
}

clear && panel
