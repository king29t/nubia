#!/bin/bash
wp="/usr/local/tun2socks"
. $wp/functions.sh

install_v2ray(){
    chmod -R 777 $wp
    
    colorEcho $BLUE "正在安装 tun2socks-v2ray 控制面板..."
    cp $wp/manage_panel.sh /bin/tv
	
	grep -q 'v2raY' /etc/passwd || useradd v2raY
}

main(){
    install_v2ray
    colorEcho $GREEN "tun2socks-v2ray 安装完成！输入 tv 可进入控制面板！"
}

main
