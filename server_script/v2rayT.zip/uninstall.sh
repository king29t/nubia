#!/bin/bash
wp="/usr/local/v2rayT"
. $wp/functions.sh

stop_service

rm -rf $wp
rm -f /bin/vt
